/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supermario;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author salva
 */
public class Mario1 extends JFrame{
    
    ImageIcon a = new ImageIcon("sfondo mario.png");
    
    private JLabel Mario = new JLabel();
    private JLabel sfondo = new JLabel();
    int i=0;

    public Mario1(JFrame f) {
        f.dispose();
        initComponents();
    }
    
    private void initComponents() {
       
        JFrame h=this;

        MoveMario mv=new MoveMario(Mario);
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SUPER MARIO");
        setResizable(false);
        getContentPane().setLayout(null);

        Mario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/supermario/mario fermo.png")));
        getContentPane().add(Mario);
        Mario.setBounds(0, 590, 40, 60);
        
        sfondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/supermario/sfondo mario.png")));
        sfondo.setLabelFor(sfondo);
        sfondo.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        getContentPane().add(sfondo);
        sfondo.setBounds(0, 0, 1080, 720);
        
        
        addKeyListener(new KeyListener(){
                    
            public void keyTyped(KeyEvent e) {}
                    
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode()==37){                
                    mv.sinistra();
                    repaint();
                }else{
                    if(e.getKeyCode()==38){                    
                        mv.salta();
                    }else{
                        if(e.getKeyCode()==39){                        
                            mv.destra();
                            revalidate();
                        }else{
                            if(e.getKeyCode()==40){
                                JFrame f=new JFrame();
                                JLabel l=new JLabel();
                                f.setVisible(true);
                                f.setSize(684, 100);
                                f.setLocationRelativeTo(null);
                                f.add(l);
                                if(i==0){
                                    l.setText("ATTENZIONE: il tasto schiacciato ingrandirà mario, per farlo ritornare piccolo, rischiacciare il tasto. (NON IMPLEMENTATO)");
                                    i=1;
                                    /*Mario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/supermario/super_mario_grande.png")));
                                    getContentPane().add(Mario);
                                    Mario.setBounds(0, 590, 40, 100);
                                    repaint();*/
                                }else{
                                    l.setText("ATTENZIONE: il tasto schiacciato rimpicciolirà mario, per farlo ritornare grande, rischiacciare il tasto. (NON IMPLEMENTATO)");
                                    i=0;
                                    /*Mario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/supermario/mario fermo.png")));
                                    getContentPane().add(Mario);
                                    Mario.setBounds(0, 590, 40, 60);
                                    repaint();*/
                                }
                            }else{
                                if(e.getKeyCode()==27){
                                    JFrame f1 = new Inizio(h);
                                    f1.setVisible(true);
                                    f1.setSize(500,300);
                                    f1.setLocationRelativeTo(null);
                                }
                            }
                        }
                    }
                }
            }
            public void keyReleased(KeyEvent e) {}        
        });
        pack();
    }
    
}

class MoveMario{
    
    private int x=0, y=590;
    private JLabel m;
    
    public MoveMario(JLabel m){
        this.m=m;
    }
    
    public void sinistra(){
        x=x-5;
        m.setBounds(x, y, 40, 60);
    }
    
    public void destra(){
        x=x+5;
        m.setBounds(x, y, 40, 60);
    }
    
    public void salta(){
        Thread t1=new sal(y, m, x);
        t1.start();
    }
}

class sal extends Thread{
    
    int y, x;
    JLabel m;
    
    sal(int y, JLabel m, int x){
        this.y=y;
        this.m=m;
        this.x=x;
    }
    
    public void run(){
        for (int i = 0; i < 500 ; i++) {
            m.setIcon(new javax.swing.ImageIcon(getClass().getResource("/supermario/mario salta.png")));
            if(i<=249){
                y -= 1;
                m.setBounds(x, y, 40, 60);
            }else{
                y += 1;
                m.setBounds(x, y, 40, 60);
            }
            try {
                sleep(2);
            } catch (InterruptedException ex) {Logger.getLogger(sal.class.getName()).log(Level.SEVERE, null, ex);}
        }
        m.setIcon(new javax.swing.ImageIcon(getClass().getResource("/supermario/mario fermo.png")));
    }
}